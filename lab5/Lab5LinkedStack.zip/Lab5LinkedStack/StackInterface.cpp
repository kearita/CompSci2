#include "StackInterface.h"

StackInterface::StackInterface()
{
    //ctor
}

StackInterface::~StackInterface()
{
    //dtor
}
