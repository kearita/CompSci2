#include "LinkedStack.h"

LinkedStack::LinkedStack()
{
    //ctor
}

LinkedStack::~LinkedStack()
{
    //dtor
}
